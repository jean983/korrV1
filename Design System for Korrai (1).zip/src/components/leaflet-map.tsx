import React, { useEffect, useRef, useState } from 'react';
import { Badge } from './ui/badge';
import {
  MapPin,
  Layers,
  Activity,
  Building2,
  FlaskConical,
  Satellite,
  TrendingUp,
  Grid3x3
} from 'lucide-react';
import { Asset, ShapefileLayer } from '../lib/mock-data';

// Import Leaflet dynamically to avoid SSR issues
import type * as L from 'leaflet';

export type BaseMapLayer = 'street' | 'satellite' | 'terrain' | 'topo';

interface LeafletMapProps {
  assets: Asset[];
  selectedAsset: Asset | null;
  onAssetClick: (asset: Asset) => void;
  overlays?: {
    id: string;
    name: string;
    enabled: boolean;
    color: string;
  }[];
  shapefileLayers?: ShapefileLayer[];
  baseLayer?: BaseMapLayer;
  className?: string;
  enableZoom?: boolean;
}

export function LeafletMap({
  assets,
  selectedAsset,
  onAssetClick,
  overlays = [],
  shapefileLayers = [],
  baseLayer = 'street',
  className = '',
  enableZoom = true
}: LeafletMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const overlayLayersRef = useRef<L.Layer[]>([]);
  const shapefileLayersRef = useRef<L.GeoJSON[]>([]);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const [leaflet, setLeaflet] = useState<typeof L | null>(null);

  // Load Leaflet dynamically
  useEffect(() => {
    import('leaflet').then((L) => {
      setLeaflet(L);
    });
  }, []);

  // Initialize map
  useEffect(() => {
    if (!leaflet || !mapRef.current || mapInstanceRef.current) return;

    // Calculate center from assets
    const avgLat = assets.reduce((sum, asset) => sum + asset.location.lat, 0) / assets.length;
    const avgLng = assets.reduce((sum, asset) => sum + asset.location.lng, 0) / assets.length;

    // Create map
    const map = leaflet.map(mapRef.current, {
      center: [avgLat, avgLng],
      zoom: 13,
      zoomControl: enableZoom,
      scrollWheelZoom: enableZoom,
      doubleClickZoom: enableZoom,
      dragging: true,
      attributionControl: true
    });

    // Add initial tile layer
    const getTileLayer = (layer: BaseMapLayer) => {
      switch (layer) {
        case 'satellite':
          return leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri, Maxar, Earthstar Geographics',
            maxZoom: 19
          });
        case 'terrain':
          return leaflet.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenTopoMap contributors',
            maxZoom: 17
          });
        case 'topo':
          return leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri',
            maxZoom: 19
          });
        case 'street':
        default:
          return leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
          });
      }
    };

    tileLayerRef.current = getTileLayer(baseLayer).addTo(map);

    mapInstanceRef.current = map;

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [leaflet, assets, enableZoom]);

  // Create custom marker icon
  const createCustomIcon = (
    type: string,
    isSelected: boolean,
    L: typeof import('leaflet')
  ): L.DivIcon => {
    const getIconHtml = () => {
      const iconMap: Record<string, string> = {
        borehole: 'layers',
        monitoring: 'activity',
        infrastructure: 'building-2'
      };
      
      const colorMap: Record<string, string> = {
        borehole: '#186181',
        monitoring: '#769f86',
        infrastructure: '#1d2759'
      };

      const icon = iconMap[type] || 'map-pin';
      const color = colorMap[type] || '#186181';
      const bgColor = isSelected ? color : '#ffffff';
      const iconColor = isSelected ? '#ffffff' : color;

      return `
        <div style="position: relative; width: 32px; height: 32px;">
          <div style="
            width: 32px;
            height: 32px;
            background-color: ${bgColor};
            border: 3px solid ${color};
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            ${isSelected ? 'transform: scale(1.2);' : ''}
          ">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              ${getIconSvgPath(icon)}
            </svg>
          </div>
          ${isSelected ? `
            <div style="
              position: absolute;
              top: 0;
              left: 0;
              width: 32px;
              height: 32px;
              background-color: ${color};
              opacity: 0.2;
              border-radius: 50%;
              animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
            "></div>
          ` : ''}
        </div>
      `;
    };

    return L.divIcon({
      html: getIconHtml(),
      className: 'custom-marker',
      iconSize: [32, 32],
      iconAnchor: [16, 16],
      popupAnchor: [0, -16]
    });
  };

  const getIconSvgPath = (icon: string): string => {
    const paths: Record<string, string> = {
      'layers': '<polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>',
      'activity': '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>',
      'building-2': '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path>',
      'map-pin': '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle>'
    };
    return paths[icon] || paths['map-pin'];
  };

  // Update markers when assets or selection changes
  useEffect(() => {
    if (!leaflet || !mapInstanceRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Filter assets based on overlays
    const visibleAssets = assets.filter(asset => {
      if (overlays.length === 0) return true;
      
      const boreholeOverlay = overlays.find(o => o.id === 'boreholes');
      const monitoringOverlay = overlays.find(o => o.id === 'monitoring');
      
      if (asset.type === 'borehole' && boreholeOverlay && !boreholeOverlay.enabled) return false;
      if (asset.type === 'monitoring' && monitoringOverlay && !monitoringOverlay.enabled) return false;
      
      return true;
    });

    // Add markers for visible assets
    visibleAssets.forEach(asset => {
      const isSelected = selectedAsset?.id === asset.id;
      const marker = leaflet
        .marker([asset.location.lat, asset.location.lng], {
          icon: createCustomIcon(asset.type, isSelected, leaflet)
        })
        .addTo(mapInstanceRef.current!);

      // Add popup
      const popupContent = `
        <div style="padding: 8px;">
          <div style="font-weight: 500; margin-bottom: 4px;">${asset.name}</div>
          <div style="font-size: 12px; color: #6b7280;">
            ${asset.type.charAt(0).toUpperCase() + asset.type.slice(1)}
          </div>
          ${asset.type === 'borehole' ? `<div style="font-size: 12px; color: #6b7280; margin-top: 2px;">Depth: ${(asset as any).depth}m</div>` : ''}
        </div>
      `;
      
      marker.bindPopup(popupContent);

      // Add click handler
      marker.on('click', () => {
        onAssetClick(asset);
      });

      markersRef.current.push(marker);
    });

    // Center on selected asset
    if (selectedAsset) {
      mapInstanceRef.current.setView(
        [selectedAsset.location.lat, selectedAsset.location.lng],
        Math.max(mapInstanceRef.current.getZoom(), 15),
        { animate: true }
      );
    }
  }, [leaflet, assets, selectedAsset, overlays, onAssetClick]);

  // Update overlay layers
  useEffect(() => {
    if (!leaflet || !mapInstanceRef.current) return;

    // Clear existing overlay layers
    overlayLayersRef.current.forEach(layer => layer.remove());
    overlayLayersRef.current = [];

    // Add settlement contours if enabled
    const settlementOverlay = overlays.find(o => o.id === 'settlement');
    if (settlementOverlay && settlementOverlay.enabled) {
      const avgLat = assets.reduce((sum, asset) => sum + asset.location.lat, 0) / assets.length;
      const avgLng = assets.reduce((sum, asset) => sum + asset.location.lng, 0) / assets.length;

      const circle1 = leaflet.circle([avgLat, avgLng], {
        color: '#ef4444',
        fillColor: '#ef4444',
        fillOpacity: 0.05,
        radius: 300,
        weight: 2,
        dashArray: '5, 5'
      }).addTo(mapInstanceRef.current);

      const circle2 = leaflet.circle([avgLat, avgLng], {
        color: '#f59e0b',
        fillColor: '#f59e0b',
        fillOpacity: 0.05,
        radius: 500,
        weight: 2,
        dashArray: '5, 5'
      }).addTo(mapInstanceRef.current);

      overlayLayersRef.current.push(circle1, circle2);
    }

    // Add soil sample markers if enabled
    const soilOverlay = overlays.find(o => o.id === 'soil');
    if (soilOverlay && soilOverlay.enabled && assets.length > 0) {
      const avgLat = assets.reduce((sum, asset) => sum + asset.location.lat, 0) / assets.length;
      const avgLng = assets.reduce((sum, asset) => sum + asset.location.lng, 0) / assets.length;

      // Add a few soil sample points around the center
      const soilPoints = [
        [avgLat + 0.001, avgLng],
        [avgLat - 0.001, avgLng + 0.001],
        [avgLat, avgLng - 0.001]
      ];

      soilPoints.forEach(([lat, lng]) => {
        const soilIcon = leaflet.divIcon({
          html: `
            <div style="
              width: 24px;
              height: 24px;
              background-color: #f97316;
              border: 2px solid white;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            ">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2"></path>
                <path d="M8.5 2h7"></path>
                <path d="M7 16h10"></path>
              </svg>
            </div>
          `,
          className: 'custom-marker',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        const marker = leaflet.marker([lat, lng], { icon: soilIcon })
          .addTo(mapInstanceRef.current!)
          .bindPopup('<div style="padding: 4px 8px; font-size: 12px;">Soil Sample</div>');

        overlayLayersRef.current.push(marker);
      });
    }
  }, [leaflet, overlays, assets]);

  // Render shapefile layers
  useEffect(() => {
    if (!leaflet || !mapInstanceRef.current) return;

    // Clear existing shapefile layers
    shapefileLayersRef.current.forEach(layer => layer.remove());
    shapefileLayersRef.current = [];

    // Add visible shapefile layers
    shapefileLayers
      .filter(layer => layer.visible && layer.geoJsonData)
      .forEach(layer => {
        try {
          const geoJsonLayer = leaflet.geoJSON(layer.geoJsonData, {
            style: (feature) => {
              // Style for polygons and lines
              return {
                color: layer.color,
                fillColor: layer.color,
                fillOpacity: layer.opacity * 0.5,
                weight: 2,
                opacity: layer.opacity
              };
            },
            pointToLayer: (feature, latlng) => {
              // Custom markers for point features
              const icon = leaflet.divIcon({
                html: `
                  <div style="
                    width: 12px;
                    height: 12px;
                    background-color: ${layer.color};
                    border: 2px solid white;
                    border-radius: 50%;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                  "></div>
                `,
                className: 'shapefile-point-marker',
                iconSize: [12, 12],
                iconAnchor: [6, 6]
              });
              return leaflet.marker(latlng, { icon });
            },
            onEachFeature: (feature, featureLayer) => {
              // Add popup with feature properties
              if (feature.properties) {
                const props = feature.properties;
                const popupContent = `
                  <div style="padding: 8px; min-width: 150px;">
                    <div style="font-weight: 500; margin-bottom: 6px; color: ${layer.color};">
                      ${layer.name}
                    </div>
                    ${Object.entries(props).slice(0, 5).map(([key, value]) => `
                      <div style="font-size: 11px; margin-bottom: 2px;">
                        <span style="color: #6b7280; font-weight: 500;">${key}:</span>
                        <span style="margin-left: 4px;">${value}</span>
                      </div>
                    `).join('')}
                    ${Object.keys(props).length > 5 ? 
                      `<div style="font-size: 10px; color: #9ca3af; margin-top: 4px;">
                        +${Object.keys(props).length - 5} more properties
                      </div>` : ''
                    }
                  </div>
                `;
                featureLayer.bindPopup(popupContent);
              }
            }
          }).addTo(mapInstanceRef.current!);

          shapefileLayersRef.current.push(geoJsonLayer);
        } catch (error) {
          console.error(`Error rendering shapefile layer ${layer.name}:`, error);
        }
      });
  }, [leaflet, shapefileLayers]);

  // Handle base layer changes
  useEffect(() => {
    if (!leaflet || !mapInstanceRef.current || !tileLayerRef.current) return;

    const getTileLayer = (layer: BaseMapLayer) => {
      switch (layer) {
        case 'satellite':
          return leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri, Maxar, Earthstar Geographics',
            maxZoom: 19
          });
        case 'terrain':
          return leaflet.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenTopoMap contributors',
            maxZoom: 17
          });
        case 'topo':
          return leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri',
            maxZoom: 19
          });
        case 'street':
        default:
          return leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
          });
      }
    };

    // Remove old tile layer
    tileLayerRef.current.remove();
    
    // Add new tile layer
    tileLayerRef.current = getTileLayer(baseLayer).addTo(mapInstanceRef.current);
  }, [leaflet, baseLayer]);

  return (
    <div ref={mapRef} className={`w-full h-full ${className}`} />
  );
}
