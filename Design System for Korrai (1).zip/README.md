
  # Design System for Korrai

  This is a code bundle for Design System for Korrai. The original project is available at https://www.figma.com/design/OqHu6ALBImkmVRxJxnWB0b/Design-System-for-Korrai.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  